package br.edu.ibmec.cloud.ecommerce_cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceCloudApplication.class, args);
	}

}
